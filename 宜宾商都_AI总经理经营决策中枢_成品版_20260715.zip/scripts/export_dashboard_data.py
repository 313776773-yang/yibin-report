#!/usr/bin/env python3
"""Export the reviewed Excel operating model into the HTML dashboard contract."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path

import openpyxl


def serialise(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat(sep=" ") if isinstance(value, datetime) else value.isoformat()
    return value


def as_number(value, default=0.0):
    return float(value) if isinstance(value, (int, float)) else default


def records(workbook, sheet_name):
    sheet = workbook[sheet_name]
    headers = [cell.value for cell in sheet[5]]
    result = []
    for row in sheet.iter_rows(min_row=6, max_row=sheet.max_row, values_only=True):
        if not any(value is not None for value in row):
            continue
        item = {headers[index]: serialise(value) for index, value in enumerate(row[: len(headers)]) if headers[index]}
        result.append(item)
    return result


def by_code(rows, key="account_code"):
    return {row.get(key): row for row in rows}


def export(input_file: Path):
    wb = openpyxl.load_workbook(input_file, data_only=True, read_only=True)
    dash = wb["01_管理驾驶舱"]

    metrics = {
        "noi_budget": as_number(dash["B6"].value),
        "noi_income": as_number(dash["B7"].value),
        "noi_cost": as_number(dash["B8"].value),
        "noi_forecast": as_number(dash["B9"].value),
        "noi_gap": as_number(dash["B10"].value),
        "noi_achievement": as_number(dash["B11"].value),
        "sales_reported": as_number(dash["D6"].value),
        "sales_comparable_current": as_number(dash["D7"].value),
        "sales_comparable_prior": as_number(dash["D8"].value),
        "sales_yoy": as_number(dash["D9"].value),
        "sales_merchant_coverage": as_number(dash["D10"].value),
        "sales_area_coverage": as_number(dash["D11"].value),
        "traffic": as_number(dash["F6"].value),
        "traffic_baseline": as_number(dash["F7"].value),
        "traffic_vs_baseline": as_number(dash["F8"].value),
        "traffic_target": as_number(dash["F9"].value),
        "traffic_achievement": as_number(dash["F10"].value),
        "traffic_online_rate": as_number(dash["F11"].value),
        "lettable_area": as_number(dash["H6"].value),
        "signed_area": as_number(dash["H7"].value),
        "effective_area": as_number(dash["H8"].value),
        "billing_area": as_number(dash["H9"].value),
        "effective_area_rate": as_number(dash["H10"].value),
        "signed_effective_gap": as_number(dash["H11"].value),
        "receivable": as_number(dash["J6"].value),
        "cash_received": as_number(dash["J7"].value),
        "cash_collection_rate": as_number(dash["J8"].value),
        "cash_risk": as_number(dash["J9"].value),
        "scenario_b_noi": as_number(dash["J10"].value),
        "validated_noi": as_number(dash["J11"].value),
    }

    income_rows = records(wb, "11_经营收入")
    expense_rows = records(wb, "12_运营支出")
    sales_rows = records(wb, "15_销售日报")
    traffic_rows = records(wb, "16_客流数据")
    status_rows = records(wb, "14_营业状态")
    marketing_rows = records(wb, "17_会员营销")
    energy_rows = records(wb, "18_物业能耗")
    risk_rows = records(wb, "20_客诉风险")
    tasks = records(wb, "21_责任任务")
    effects = records(wb, "22_效果验证")
    ai_decisions = records(wb, "23_AI决策日志")

    income = by_code(income_rows)
    expense = by_code(expense_rows)

    traffic_daily = defaultdict(lambda: {"actual": 0, "baseline": 0, "target": 0, "online": []})
    for row in traffic_rows:
        if row.get("flow_type") != "项目入口" or row.get("valid_flag") != 1:
            continue
        day = str(row.get("date_key", ""))[:10]
        traffic_daily[day]["actual"] += as_number(row.get("in_count"))
        traffic_daily[day]["baseline"] += as_number(row.get("baseline_count"))
        traffic_daily[day]["target"] += as_number(row.get("target_count"))
        traffic_daily[day]["online"].append(as_number(row.get("online_rate"), 1))
    traffic_trend = [
        {
            "date": day,
            "actual": round(values["actual"]),
            "baseline": round(values["baseline"]),
            "target": round(values["target"]),
            "online_rate": sum(values["online"]) / max(1, len(values["online"])),
        }
        for day, values in sorted(traffic_daily.items())
    ]

    sales_status = Counter(row.get("report_status") or "未标注" for row in sales_rows)
    operating_status = Counter(row.get("operating_status") or "未标注" for row in status_rows)
    area_by_status = defaultdict(float)
    for row in status_rows:
        area_by_status[row.get("operating_status") or "未标注"] += as_number(row.get("gross_leasable_area"))

    energy_actual = sum(as_number(row.get("cost_amount")) for row in energy_rows)
    energy_budget = sum(as_number(row.get("budget_cost")) for row in energy_rows)
    risk_by_level = Counter(row.get("risk_level") or "未标注" for row in risk_rows)
    task_by_status = Counter(row.get("task_status") or "未标注" for row in tasks)
    completed_tasks = task_by_status.get("已完成", 0) + task_by_status.get("已关闭", 0)
    task_completion = completed_tasks / max(1, len(tasks))
    effect_actual = sum(as_number(row.get("actual_value")) for row in effects)
    effect_expected = sum(as_number(row.get("expected_value")) for row in effects)
    positive_expected = sum(max(0, as_number(row.get("expected_value"))) for row in effects)
    effect_attainment = effect_actual / positive_expected if positive_expected else 0

    activity = marketing_rows[0] if marketing_rows else {}
    activity_lift = (
        (as_number(activity.get("actual_footfall")) - as_number(activity.get("baseline_footfall")))
        / as_number(activity.get("baseline_footfall"), 1)
    ) if activity else 0

    north_stars = [
        {
            "id": "noi",
            "name": "NOI预测",
            "value": metrics["noi_forecast"],
            "unit": "万元",
            "target": metrics["noi_budget"],
            "achievement": metrics["noi_achievement"],
            "delta": metrics["noi_gap"],
            "status": "risk" if metrics["noi_achievement"] < 0.95 else "watch",
            "confidence": 0.86,
            "definition": "本月预计经营收入减预计运营支出；经营现金回款单独展示，不与权责发生制NOI混算。",
            "source": "10_NOI预算、11_经营收入、12_运营支出",
        },
        {
            "id": "sales",
            "name": "可统计销售额",
            "value": metrics["sales_reported"],
            "unit": "万元",
            "target": None,
            "achievement": metrics["sales_yoy"],
            "delta": metrics["sales_comparable_current"] - metrics["sales_comparable_prior"],
            "status": "watch" if metrics["sales_area_coverage"] < 0.85 else "good",
            "confidence": 0.78,
            "definition": "仅统计已有效报数商户；必须同时显示商户与面积覆盖率，不外推未覆盖商户。",
            "source": "15_销售日报",
            "coverage": {
                "merchant": metrics["sales_merchant_coverage"],
                "area": metrics["sales_area_coverage"],
            },
        },
        {
            "id": "traffic",
            "name": "项目入口客流",
            "value": metrics["traffic"],
            "unit": "人次",
            "target": metrics["traffic_target"],
            "achievement": metrics["traffic_achievement"],
            "delta": metrics["traffic"] - metrics["traffic_baseline"],
            "status": "watch" if metrics["traffic_achievement"] < 0.98 else "good",
            "confidence": 0.91,
            "definition": "有效入口设备客流合计；项目入口、楼层、商户、活动与停车客流不得相加。",
            "source": "16_客流数据、09_经营日历",
            "coverage": {"device_online": metrics["traffic_online_rate"]},
        },
        {
            "id": "area",
            "name": "有效开业面积",
            "value": metrics["effective_area"],
            "unit": "㎡",
            "target": metrics["lettable_area"],
            "achievement": metrics["effective_area_rate"],
            "delta": metrics["effective_area"] - metrics["signed_area"],
            "status": "watch" if metrics["effective_area_rate"] < 0.90 else "good",
            "confidence": 0.95,
            "definition": "完成开业检查、无一票否决项、当前正常营业且能持续产生经营价值的租赁面积。",
            "source": "06_铺位主档、08_合同租约、14_营业状态",
        },
    ]

    causal_nodes = [
        {"id": "noi", "label": "NOI预测", "value": metrics["noi_forecast"], "unit": "万元", "parent": None, "direction": "result", "impact": metrics["noi_gap"], "status": "risk", "source": "11_经营收入、12_运营支出"},
        {"id": "income", "label": "预测收入", "value": metrics["noi_income"], "unit": "万元", "parent": "noi", "direction": "positive", "impact": -12, "status": "watch", "source": "11_经营收入"},
        {"id": "cost", "label": "预测成本", "value": metrics["noi_cost"], "unit": "万元", "parent": "noi", "direction": "negative", "impact": -22, "status": "risk", "source": "12_运营支出"},
        {"id": "rent", "label": "固定租金", "value": as_number(income.get("INC_RENT", {}).get("amount")), "unit": "万元", "parent": "income", "direction": "positive", "impact": -4, "status": "watch", "source": "11_经营收入"},
        {"id": "other_income", "label": "物管费及其他收入", "value": as_number(income.get("INC_OTHER", {}).get("amount")), "unit": "万元", "parent": "income", "direction": "positive", "impact": -8, "status": "watch", "source": "11_经营收入"},
        {"id": "energy", "label": "能耗", "value": as_number(expense.get("EXP_ENERGY", {}).get("amount")), "unit": "万元", "parent": "cost", "direction": "negative", "impact": -8, "status": "risk", "source": "12_运营支出、18_物业能耗"},
        {"id": "maintenance", "label": "维保", "value": as_number(expense.get("EXP_MAINT", {}).get("amount")), "unit": "万元", "parent": "cost", "direction": "negative", "impact": -6, "status": "watch", "source": "12_运营支出、19_设备工单"},
        {"id": "other_cost", "label": "其他运营成本", "value": as_number(expense.get("EXP_OTHER", {}).get("amount")), "unit": "万元", "parent": "cost", "direction": "negative", "impact": -8, "status": "watch", "source": "12_运营支出"},
        {"id": "area", "label": "有效开业面积", "value": metrics["effective_area"], "unit": "㎡", "parent": "rent", "direction": "driver", "impact": -3.5, "status": "watch", "source": "14_营业状态"},
        {"id": "traffic", "label": "项目入口客流", "value": metrics["traffic"], "unit": "人次", "parent": "other_income", "direction": "driver", "impact": -2.1, "status": "watch", "source": "16_客流数据"},
        {"id": "sales", "label": "可统计销售额", "value": metrics["sales_reported"], "unit": "万元", "parent": "other_income", "direction": "driver", "impact": None, "status": "limited", "source": "15_销售日报"},
    ]

    decision_queue = [
        {
            "id": "D001", "priority": "P1", "title": "本月NOI预测缺口改善", "domain": "NOI、预算与经营现金",
            "impact": "预计缺口34万元", "deadline": "今日决策", "score": 91, "confidence": 0.86,
            "fact": "预算NOI 520万元，预测486万元，达成93.5%。",
            "inference": "目前更可干预的变量集中在能耗、维保、可确认起租事项与其他经营收入；销售覆盖不足，不作为确定性缺口原因。",
            "recommendation": "采纳稳健方案B，预计净改善12万元，并将每项动作拆成任务后验证。",
            "affected": ["NOI预测", "有效开业面积"], "authorization": "项目权限内",
        },
        {
            "id": "D002", "priority": "P1", "title": "经营现金风险专项跟踪", "domain": "NOI、预算与经营现金",
            "impact": "回款风险28万元", "deadline": "今日确认", "score": 86, "confidence": 0.93,
            "fact": "当期应收600万元、实收572万元，收缴率95.3%。",
            "inference": "风险首先影响现金，不应直接写成NOI增益；需按账龄、争议与履约状态分层。",
            "recommendation": "财务牵头形成28万元风险清单，区分可催收、争议待确认和坏账风险。",
            "affected": ["经营现金"], "authorization": "项目权限内",
        },
        {
            "id": "D003", "priority": "P1", "title": "能耗费用偏差压降", "domain": "物业工程、能耗与现场品质",
            "impact": f"较预算增加{energy_actual - energy_budget:.1f}万元", "deadline": "24小时内", "score": 82, "confidence": 0.88,
            "fact": f"能耗及水务费用{energy_actual:.1f}万元，预算{energy_budget:.1f}万元。",
            "inference": "公共区域空调运行时长与重点设备效率是当前高可干预项，需先排除天气与营业时长影响。",
            "recommendation": "核验运行策略并试行分时控制，保留舒适度和客诉作为护栏指标。",
            "affected": ["NOI预测", "客流"], "authorization": "项目权限内",
        },
        {
            "id": "D004", "priority": "P2", "title": "销售数据覆盖率治理", "domain": "商户经营、销售与一商一策",
            "impact": "限制销售归因可信度", "deadline": "本周推进", "score": 75, "confidence": 0.78,
            "fact": f"商户覆盖率{metrics['sales_merchant_coverage']:.1%}，面积覆盖率{metrics['sales_area_coverage']:.1%}。",
            "inference": "覆盖率变化可能被误判为销售增长；未覆盖商户不得外推。",
            "recommendation": "优先补齐已约定报数但迟报商户，固定样本与全量口径同时保留。",
            "affected": ["可统计销售额"], "authorization": "部门协同",
        },
        {
            "id": "D005", "priority": "P2", "title": "签约面积向有效开业面积转化", "domain": "资产、出租、租约与招商",
            "impact": f"转化差额{metrics['signed_effective_gap']:.0f}㎡", "deadline": "本周排查", "score": 73, "confidence": 0.95,
            "fact": f"已签约{metrics['signed_area']:.0f}㎡，有效开业{metrics['effective_area']:.0f}㎡，差额{metrics['signed_effective_gap']:.0f}㎡。",
            "inference": "差额由暂停营业、筹备中、空置及检查门槛等不同状态构成，不能统一归因为装修延期。",
            "recommendation": "按铺位状态和经济影响分层处理；装修筹开仅作为其中一个下钻环节。",
            "affected": ["有效开业面积", "NOI预测"], "authorization": "跨部门协同",
        },
    ]

    domains = [
        {"id": "finance", "name": "NOI、预算与经营现金", "owner": "财务/总经办", "status": "risk", "score": 72, "headline": "预测NOI达成93.5%，现金风险需单列", "metrics": [{"label": "预测NOI", "value": metrics["noi_forecast"], "unit": "万元"}, {"label": "缺口", "value": metrics["noi_gap"], "unit": "万元"}, {"label": "收缴率", "value": metrics["cash_collection_rate"], "format": "percent"}], "questions": ["缺口来自收入端还是成本端？", "哪些差异可以在项目权限内追回？", "回款风险是否被错误计入NOI？"], "source": "10_NOI预算、11_经营收入、12_运营支出、13_应收回款"},
        {"id": "asset", "name": "资产、出租、租约与招商", "owner": "招商/租约/运营", "status": "watch", "score": 81, "headline": "有效开业率87.0%，需提升签约转化质量", "metrics": [{"label": "签约面积", "value": metrics["signed_area"], "unit": "㎡"}, {"label": "有效开业面积", "value": metrics["effective_area"], "unit": "㎡"}, {"label": "起租计费面积", "value": metrics["billing_area"], "unit": "㎡"}], "questions": ["哪些面积未形成经营产能？", "租约到期与空置风险在哪里？", "筹开、暂停和空置分别如何处理？"], "source": "06_铺位主档、08_合同租约、14_营业状态"},
        {"id": "merchant", "name": "商户经营、销售与一商一策", "owner": "运营", "status": "watch", "score": 77, "headline": "固定样本销售同比+2.1%，但覆盖仍不足", "metrics": [{"label": "可统计销售", "value": metrics["sales_reported"], "unit": "万元"}, {"label": "固定样本同比", "value": metrics["sales_yoy"], "format": "percent"}, {"label": "面积覆盖", "value": metrics["sales_area_coverage"], "format": "percent"}], "questions": ["增长来自真实经营还是覆盖率变化？", "哪些商户偏离自身基线？", "一商一策动作是否产生效果？"], "source": "07_商户主档、15_销售日报"},
        {"id": "growth", "name": "客流、会员与营销增长", "owner": "营销/会员", "status": "watch", "score": 79, "headline": "客流达成95.5%，需解释基线偏差", "metrics": [{"label": "项目入口客流", "value": metrics["traffic"], "unit": "人次"}, {"label": "目标达成", "value": metrics["traffic_achievement"], "format": "percent"}, {"label": "设备在线", "value": metrics["traffic_online_rate"], "format": "percent"}], "questions": ["偏差是否来自天气、节假日或活动？", "不同入口变化能否被设备状态解释？", "活动增量是否有可信对照？"], "source": "09_经营日历、16_客流数据、17_会员营销"},
        {"id": "property", "name": "物业工程、能耗与现场品质", "owner": "物业工程", "status": "risk", "score": 70, "headline": f"能耗费用较预算增加{energy_actual - energy_budget:.1f}万元", "metrics": [{"label": "实际费用", "value": energy_actual, "unit": "万元"}, {"label": "预算费用", "value": energy_budget, "unit": "万元"}, {"label": "偏差", "value": energy_actual - energy_budget, "unit": "万元"}], "questions": ["偏差是营业变化还是效率问题？", "工单是否影响营业与顾客体验？", "降耗动作是否触发舒适度护栏？"], "source": "18_物业能耗、19_设备工单"},
        {"id": "risk", "name": "服务、安全、合规与风险", "owner": "客服/安全/物业", "status": "watch", "score": 84, "headline": f"当前{len(risk_rows)}项风险事件，P0为{risk_by_level.get('P0', 0)}", "metrics": [{"label": "风险事件", "value": len(risk_rows), "unit": "项"}, {"label": "P0事件", "value": risk_by_level.get("P0", 0), "unit": "项"}, {"label": "处理中", "value": sum(1 for row in risk_rows if row.get("current_status") == "处理中"), "unit": "项"}], "questions": ["是否存在一票否决或重大安全事项？", "相同问题是否重复发生？", "风险升级是否符合授权矩阵？"], "source": "20_客诉风险"},
        {"id": "execution", "name": "组织执行、任务与复盘", "owner": "总经办/各部门", "status": "good", "score": 89, "headline": "任务已完成并进入效果验证", "metrics": [{"label": "任务完成率", "value": task_completion, "format": "percent"}, {"label": "实际净改善", "value": effect_actual, "unit": "万元"}, {"label": "验证达成", "value": effect_attainment, "format": "percent"}], "questions": ["决策是否转化为明确责任任务？", "完成是否有证据而非口头确认？", "实际效果能否归因于本次动作？"], "source": "21_责任任务、22_效果验证、23_AI决策日志"},
    ]

    source_map = [
        {"display": "NOI预测", "sources": ["10_NOI预算", "11_经营收入", "12_运营支出"], "refresh": "数据更新触发", "owner": "财务/总经办", "rule": "预测收入-预测支出"},
        {"display": "可统计销售额", "sources": ["15_销售日报"], "refresh": "每日/报数后", "owner": "运营", "rule": "只统计已报；同时显示双覆盖率"},
        {"display": "项目入口客流", "sources": ["16_客流数据", "09_经营日历"], "refresh": "小时/每日", "owner": "营销/系统管理员", "rule": "有效设备；不同客流类型不可相加"},
        {"display": "有效开业面积", "sources": ["06_铺位主档", "08_合同租约", "14_营业状态"], "refresh": "事件/每日", "owner": "运营/租约", "rule": "正常营业+检查通过+无否决项"},
        {"display": "经营现金", "sources": ["13_应收回款"], "refresh": "每日", "owner": "财务", "rule": "与NOI分开表达"},
        {"display": "行动效果", "sources": ["21_责任任务", "22_效果验证"], "refresh": "任务完成后", "owner": "总经办/验证部门", "rule": "证据+归因置信度+干扰因素"},
    ]

    return {
        "meta": {
            "project": "重百宜宾商都",
            "product": "AI总经理经营决策中枢",
            "version": "V3.0 成品版",
            "snapshot_id": "S20260715-0900",
            "snapshot_time": "2026-07-15 09:00",
            "analysis_period": "2026年7月",
            "data_mode": "内置演示数据",
            "demo": True,
            "source_file": input_file.name,
            "boundary": "京东家电经营数据不可得；仅使用项目可确认的铺位、合同与营业状态，不进入销售、会员及顾客分析。",
        },
        "metrics": metrics,
        "north_stars": north_stars,
        "traffic_trend": traffic_trend,
        "noi_bridge": [
            {"label": "预算NOI", "value": metrics["noi_budget"], "kind": "total"},
            {"label": "收入差异", "value": -12, "kind": "negative"},
            {"label": "成本差异", "value": -22, "kind": "negative"},
            {"label": "预测NOI", "value": metrics["noi_forecast"], "kind": "total"},
        ],
        "area_funnel": [
            {"label": "可租赁面积", "value": metrics["lettable_area"]},
            {"label": "已签约面积", "value": metrics["signed_area"]},
            {"label": "起租计费面积", "value": metrics["billing_area"]},
            {"label": "有效开业面积", "value": metrics["effective_area"]},
        ],
        "sales_status": [{"label": key, "value": value} for key, value in sales_status.items()],
        "operating_status": [{"label": key, "count": value, "area": area_by_status[key]} for key, value in operating_status.items()],
        "causal_nodes": causal_nodes,
        "decision_queue": decision_queue,
        "domains": domains,
        "tasks": tasks,
        "effects": effects,
        "ai_decisions": ai_decisions,
        "scenario": {
            "baseline": metrics["noi_forecast"],
            "budget": metrics["noi_budget"],
            "presets": [
                {"id": "A", "name": "维持路径", "energy": 0, "maintenance": 0, "billing": 0, "other_income": 0, "cost": 0, "expected": 0, "risk": "低"},
                {"id": "B", "name": "稳健改善", "energy": 4.5, "maintenance": 2, "billing": 4, "other_income": 3, "cost": 1.5, "expected": 12, "risk": "中低"},
                {"id": "C", "name": "进取改善", "energy": 7, "maintenance": 4, "billing": 8, "other_income": 8, "cost": 3, "expected": 24, "risk": "中高"},
            ],
            "validated": {"choice": "B", "actual_net": effect_actual, "forecast_after": metrics["validated_noi"], "attainment": effect_actual / 12 if 12 else 0},
        },
        "data_availability": records(wb, "04_数据盘点"),
        "metric_definitions": records(wb, "02_指标口径"),
        "responsibilities": records(wb, "03_数据责任"),
        "source_map": source_map,
        "quality": {
            "status": "PASS",
            "checks": 14,
            "sales_merchant_coverage": metrics["sales_merchant_coverage"],
            "sales_area_coverage": metrics["sales_area_coverage"],
            "traffic_online_rate": metrics["traffic_online_rate"],
            "limitations": ["销售数据覆盖不足，不外推未覆盖商户", "京东经营数据不可得", "当前为结构验证用演示数据"],
        },
        "ai_pipeline": [
            {"step": 1, "name": "数据更新", "detail": "Excel基础表或系统接口产生新快照", "owner": "数据责任部门"},
            {"step": 2, "name": "指标计算", "detail": "指标引擎按统一口径重算四大北极星", "owner": "计算服务"},
            {"step": 3, "name": "异常识别", "detail": "规则与异常模型识别偏差、覆盖与风险", "owner": "规则/异常模型"},
            {"step": 4, "name": "影响测算", "detail": "预测模型估算NOI、客流与空间产能影响", "owner": "预测模型"},
            {"step": 5, "name": "知识推理", "detail": "AI读取运营手册、授权矩阵与历史案例", "owner": "大模型+知识库"},
            {"step": 6, "name": "决策卡生成", "detail": "严格区分事实、推断、方案与可信度", "owner": "AI决策编排"},
            {"step": 7, "name": "管理者确认", "detail": "总经理选择、修正或拒绝建议", "owner": "总经理"},
            {"step": 8, "name": "执行验证", "detail": "任务下达、证据回传并判断动作是否有效", "owner": "责任部门+验证部门"},
        ],
        "query_presets": [
            {"q": "本月NOI缺口在哪里？", "answer": "本月预算NOI 520万元，预测486万元，缺口34万元。当前证据显示收入端差异约12万元、成本端差异约22万元。更可干预的变量是能耗、维保、可确认起租事项和其他经营收入。28万元回款风险影响现金，不直接写成NOI增益。"},
            {"q": "销售增长可靠吗？", "answer": f"固定样本本期1230万元、同期1205万元，同比+{metrics['sales_yoy']:.1%}。但商户覆盖率仅{metrics['sales_merchant_coverage']:.1%}、面积覆盖率{metrics['sales_area_coverage']:.1%}，因此可确认固定样本增长，不宜外推全场。"},
            {"q": "京东数据如何处理？", "answer": "京东家电是项目主力店，但其销售、会员和顾客经营数据目前不可得。本系统只使用项目能够确认的铺位、租约与营业状态，不将京东经营数据模拟进销售分析，也不以京东作为核心联动假设。"},
            {"q": "有效开业面积为什么重要？", "answer": f"可租赁面积42000㎡、已签约39900㎡、起租计费37800㎡、有效开业36540㎡。有效开业面积代表当前真正形成经营产能的空间，签约与有效开业之间的3360㎡需按暂停、筹备、空置和门槛问题分别处理。"},
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--js-output", type=Path)
    args = parser.parse_args()
    payload = export(args.input)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    args.output.write_text(text, encoding="utf-8")
    if args.js_output:
        args.js_output.parent.mkdir(parents=True, exist_ok=True)
        args.js_output.write_text("window.DEFAULT_DASHBOARD_DATA = " + text + ";\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "north_stars": len(payload["north_stars"]), "domains": len(payload["domains"]), "tasks": len(payload["tasks"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
