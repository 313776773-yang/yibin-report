#!/usr/bin/env python3
"""Build a self-contained offline HTML from the modular suite."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text(encoding="utf-8")
css = (ROOT / "assets" / "app.css").read_text(encoding="utf-8")
data_js = (ROOT / "assets" / "default-data.js").read_text(encoding="utf-8")
xlsx_js = (ROOT / "assets" / "xlsx-bridge.js").read_text(encoding="utf-8")
app_js = (ROOT / "assets" / "app.js").read_text(encoding="utf-8")

html = html.replace('<link rel="stylesheet" href="assets/app.css" />', f"<style>\n{css}\n</style>")
html = html.replace('<script src="assets/default-data.js"></script>', f"<script>\n{data_js}\n</script>")
html = html.replace('<script src="assets/xlsx-bridge.js"></script>', f"<script>\n{xlsx_js}\n</script>")
html = html.replace('<script src="assets/app.js"></script>', f"<script>\n{app_js}\n</script>")

output = ROOT / "宜宾商都_AI总经理经营决策中枢_单文件演示版.html"
output.write_text(html, encoding="utf-8")
print(output)
